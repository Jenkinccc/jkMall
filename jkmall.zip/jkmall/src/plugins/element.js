import Vue from 'vue'
import { Button,Input, Breadcrumb, BreadcrumbItem, Carousel, CarouselItem, Row,Col,Card,Pagination, InputNumber, Form, FormItem } from 'element-ui'

Vue.use(Button)
Vue.use(Input)
Vue.use(Form)
Vue.use(FormItem)
Vue.use(Breadcrumb)
Vue.use(BreadcrumbItem)
Vue.use(Carousel)
Vue.use(CarouselItem)
Vue.use(Row)
Vue.use(Col)
Vue.use(Card)
Vue.use(Pagination)
Vue.use(InputNumber)
