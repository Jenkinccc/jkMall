<template>
    <div>
        <m-header></m-header>
        <h3>导航</h3>
        <!-- 导航 -->
        <router-view></router-view>
    </div>
</template>

<script>
    import MHeader from '@/common/MHeader'
    export default {
        components:{
            MHeader,
        }
    }
</script>

<style lang="scss" scoped>

</style>